﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinanceBot.Models
{
    public class FinancialData
    {
        public string Date { get; set; }
        public string Revenue { get; set; }
    }
}
